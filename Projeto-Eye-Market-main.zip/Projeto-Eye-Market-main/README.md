# Projeto-Eye-Market
Projeto de Pesquisa e Inovação focado em monitoramento das máquinas(totens) de SuperMercados.
